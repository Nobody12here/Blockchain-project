export interface Campaign {
  minimumContribution: string;
  deadline:string;
  name: string;
  description: string;
  imageUrl: string;
  targetAmount: string;
}